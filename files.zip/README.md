# DevTeam AI 🤖

فريق ذكاء اصطناعي متكامل لأصحاب المشاريع والشركات.

## كيفية النشر على Vercel (مجاناً في 5 دقائق)

### الخطوة 1 — حمّل الملفات على GitHub
1. اذهب إلى [github.com](https://github.com) وسجّل دخولك
2. اضغط **New repository** — سمّه `devteam-ai`
3. اضغط **uploading an existing file**
4. ارفع ملف `index.html` و `vercel.json`
5. اضغط **Commit changes**

### الخطوة 2 — انشر على Vercel
1. اذهب إلى [vercel.com](https://vercel.com) وسجّل بحساب GitHub
2. اضغط **Add New Project**
3. اختر `devteam-ai` من قائمة مشاريعك
4. اضغط **Deploy** — الموقع سيكون جاهزاً خلال دقيقة!

### الخطوة 3 — فعّل الذكاء الاصطناعي
1. اذهب إلى [console.anthropic.com](https://console.anthropic.com)
2. سجّل حساباً مجانياً
3. أنشئ API Key جديد من قسم **API Keys**
4. افتح موقعك وأدخل المفتاح عند الطلب

## الملفات
- `index.html` — الموقع الكامل
- `vercel.json` — إعدادات Vercel

## لإضافة المدفوعات لاحقاً
- [Stripe](https://stripe.com) — لاستقبال الاشتراكات
- [Supabase](https://supabase.com) — لإدارة المستخدمين

---
بُني بـ Claude AI ❤️
